package com.dnb.agreement.key;

public class generateKeys {

	public static void main(String args[])
	{
		
	}
	
}
