package com.dnb.agreement.bean;

/**
 * This bean class is use to set the active and inactive key details in service bureau edit
 * @author anandkumar.b
 *
 */
public class KekAukServiceBureauBean {
	String kekGenerationNo;
	String generationDate;
	String kvv;
	String aukGenerationNo;
	String kekGenerationNo1;
	String generationDate1;
	String kvv1;
	public String getKekGenerationNo() {
		return kekGenerationNo;
	}
	public void setKekGenerationNo(String kekGenerationNo) {
		this.kekGenerationNo = kekGenerationNo;
	}
	public String getGenerationDate() {
		return generationDate;
	}
	public void setGenerationDate(String generationDate) {
		this.generationDate = generationDate;
	}
	public String getKvv() {
		return kvv;
	}
	public void setKvv(String kvv) {
		this.kvv = kvv;
	}
	public String getAukGenerationNo() {
		return aukGenerationNo;
	}
	public void setAukGenerationNo(String aukGenerationNo) {
		this.aukGenerationNo = aukGenerationNo;
	}
	public String getKekGenerationNo1() {
		return kekGenerationNo1;
	}
	public void setKekGenerationNo1(String kekGenerationNo1) {
		this.kekGenerationNo1 = kekGenerationNo1;
	}
	public String getGenerationDate1() {
		return generationDate1;
	}
	public void setGenerationDate1(String generationDate1) {
		this.generationDate1 = generationDate1;
	}
	public String getKvv1() {
		return kvv1;
	}
	public void setKvv1(String kvv1) {
		this.kvv1 = kvv1;
	}
}
