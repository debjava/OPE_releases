package com.ope.patu.payment.core;

public interface Parser 
{
	public Object parse( Object ... objects );

}
