package com.ope.patu.payments.lmp300;

/**
 * This interface is for generic for all bill payment service validations 
 * @author anandkumar.b
 */
public interface Parser 
{
	public Object parse( Object ... objects );

}
