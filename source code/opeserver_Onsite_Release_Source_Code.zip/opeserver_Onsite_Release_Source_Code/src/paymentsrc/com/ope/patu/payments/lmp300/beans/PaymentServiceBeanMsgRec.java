package com.ope.patu.payments.lmp300.beans;

/**
 * This bean class is for message record
 * @author anandkumar.b
 *
 */
public class PaymentServiceBeanMsgRec {
	String data_code,record_code,transaction_type,reserved_1,reserved_2,reserved_3,reserved_4,payees_account,message_1,message_2,
	message_3,message_4,message_5,reserved_5;

	public String getData_code() {
		return data_code;
	}

	public void setData_code(String data_code) {
		this.data_code = data_code;
	}

	public String getRecord_code() {
		return record_code;
	}

	public void setRecord_code(String record_code) {
		this.record_code = record_code;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public String getReserved_1() {
		return reserved_1;
	}

	public void setReserved_1(String reserved_1) {
		this.reserved_1 = reserved_1;
	}

	public String getReserved_2() {
		return reserved_2;
	}

	public void setReserved_2(String reserved_2) {
		this.reserved_2 = reserved_2;
	}

	public String getReserved_3() {
		return reserved_3;
	}

	public void setReserved_3(String reserved_3) {
		this.reserved_3 = reserved_3;
	}

	public String getReserved_4() {
		return reserved_4;
	}

	public void setReserved_4(String reserved_4) {
		this.reserved_4 = reserved_4;
	}

	public String getPayees_account() {
		return payees_account;
	}

	public void setPayees_account(String payees_account) {
		this.payees_account = payees_account;
	}

	public String getMessage_1() {
		return message_1;
	}

	public void setMessage_1(String message_1) {
		this.message_1 = message_1;
	}

	public String getMessage_2() {
		return message_2;
	}

	public void setMessage_2(String message_2) {
		this.message_2 = message_2;
	}

	public String getMessage_3() {
		return message_3;
	}

	public void setMessage_3(String message_3) {
		this.message_3 = message_3;
	}

	public String getMessage_4() {
		return message_4;
	}

	public void setMessage_4(String message_4) {
		this.message_4 = message_4;
	}

	public String getMessage_5() {
		return message_5;
	}

	public void setMessage_5(String message_5) {
		this.message_5 = message_5;
	}

	public String getReserved_5() {
		return reserved_5;
	}

	public void setReserved_5(String reserved_5) {
		this.reserved_5 = reserved_5;
	}
}
