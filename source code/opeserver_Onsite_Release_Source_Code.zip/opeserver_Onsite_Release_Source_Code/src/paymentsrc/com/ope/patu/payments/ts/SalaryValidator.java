package com.ope.patu.payments.ts;

public interface SalaryValidator 
{
	public Object getValidatedObject( Object ...objects );
}
