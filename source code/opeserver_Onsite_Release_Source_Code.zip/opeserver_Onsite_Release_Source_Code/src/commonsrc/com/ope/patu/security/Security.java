package com.ope.patu.security;

public interface Security 
{

}
