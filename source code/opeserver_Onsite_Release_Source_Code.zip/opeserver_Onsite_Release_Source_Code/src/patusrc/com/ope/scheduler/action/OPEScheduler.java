package com.ope.scheduler.action;

public interface OPEScheduler
{
	public void start( Object ...objects );

}
