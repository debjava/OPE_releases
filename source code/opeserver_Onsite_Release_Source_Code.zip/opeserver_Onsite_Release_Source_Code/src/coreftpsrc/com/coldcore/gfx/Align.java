/**
 * Created by IntelliJ IDEA.
 * User: sergey
 * Date: Oct 17, 2005
 * Time: 12:38:39 PM
 * Agign.
 */
package com.coldcore.gfx;

public enum Align {
  LEFT,
  RIGHT,
  TOP,
  BOTTOM,
  CENTER
}
